from tkinter import *
import numpy

#   THIS IS THE GRAPHICAL USER INTERFACE (GUI) FOR THE MENG TEAM PROJECT - PORTABLE VENTILATOR
#   DEVELOPED AND CREATED BY ALAN PRENTICE (S1829946)
#   TEAM MEMBERS: ALAN PRENTICE, ANDREW SMITH, YOUSSEF KACHKACH, WILLIAM CHESNEY, EAMON RIORDAN

def page_2():
    print("You clicked the button!")


start_screen = Tk()

start_button = Button(start_screen,
                      text="Start",
                      command = page_2,
                      font=('Arial', 20, "bold"),
                      fg="White",
                      bg="Green",
                      activeforeground='green',
                      activebackground='white')         #Displays Green Start Button at the bottom

start_button.pack(side=BOTTOM)

start_screen.title("Ventilator Project")
Ventimg = PhotoImage(file='img.png')

start_label1 = Label(start_screen,
                     text = "Welcome to the Ventilator Project",
                     font = ('Arial',38,'bold'),
                     fg = 'black',
                     relief = RAISED,
                     bd = 12,
                     padx=20,
                     pady=20,
                     image=Ventimg,
                     compound='bottom'

                     )              # Displays Title and Image of Ventilator
start_label1.pack()



start_screen.mainloop()



