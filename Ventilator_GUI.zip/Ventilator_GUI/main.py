from tkinter import *           # IMPORTS GUI TKINTER LIBRARY
import time             # TIME LIBRARY


def time_counter(seconds):              # COUNTER FUNCTION FOR IMPLEMENTATION


    minutes = seconds//60
    seconds = seconds % 60
    hours = minutes // 60
    minutes = minutes % 60

    print("time_counted: {0}:{1}:{2}".format(int(hours), int(minutes), seconds))

    input("Press Enter to Begin Counting")
    start_counting = time.time()

    input("Press to Stop Counting")
    end_counting = time.time()

    time_counted = end_counting - start_counting

    time_counter(time_counted)






#   THIS IS THE GRAPHICAL USER INTERFACE (GUI) FOR THE MENG TEAM PROJECT - PORTABLE VENTILATOR
#   DEVELOPED AND CREATED BY ALAN PRENTICE (S1829946)
#   TEAM MEMBERS: ALAN PRENTICE, ANDREW SMITH, YOUSSEF KACHKACH, WILLIAM CHESNEY, EAMON RIORDAN

weights = ['0 - 1 Stone (0 - 6.35KG)', '1 - 4 Stone(6.35KG - 25.4KG', '4 - 10 Stone (25.4kG - 63.5KG)',
           '10 - 15 Stone(63.5KG - 95.25KG)', '15 - 20 Stone (95.25KG - 127KG', '21+ Stone (133KG+)']

ages = ['0 - 2 Years', '2 - 5 Years', '5 - 10 Years', '10 - 15 Years', '16 - 20 Years', '20 - 25 Years',
        '25+ Years']



def page_final():       # STATISTICS WINDOW

    final = Tk()                # ESTABLISHES WINDOW
    final.title ("Statistics")      # CHANGES TITLE TO STATS
    final.geometry('1000x1000')     # CHANGES WINDOW DIMENSION

                                # PLACES STATISTICS BOXES ON THE SCREEN, WITH APPROPRIATE LABELS

    abc = Text(final,font=('arial',15,'bold'),width =15, height=2,borderwidth=5)
    abc.pack()
    a_for = ("Time Elapsed:")

    abc.insert('end', str(a_for))
    abc.grid(row=8, column=8)
    abc.place(x=300,y=150)

    for i in range(1000):
        print(i)

    time_box = Text(final, font=('arial', 15, 'bold'),fg='red', width=15, height=2, borderwidth=5)
    time_box.pack()
    time_box.insert('end',str(i))
    b_for = ('3' + "   s" )

    time_box.insert('end', str(b_for))
    time_box.grid(row=8, column=8)
    time_box.place(x=600, y=150)

    BPM = Text(final, font=('arial', 15, 'bold'), width=19, height=2, borderwidth=5)
    BPM.pack()
    B_for = ("Breathes Per Minute:")

    BPM.insert('end', str(B_for))
    BPM.grid(row=8, column=8)
    BPM.place(x=300, y=300)

    BPM_box = Text(final, font=('arial', 15, 'bold'), fg='red', width=15, height=2, borderwidth=5)
    BPM_box.pack()
    BPM_box.insert('end', str(i/60))
    b_for = ('3' + str(i/60))

    BPM_box.insert('end', str(b_for))
    BPM_box.grid(row=8, column=8)
    BPM_box.place(x=600, y=300)

    pulse_box = Text(final, font=('arial', 15, 'bold'), width=15, height=2, borderwidth=5)
    pulse_box.pack()
    c_for = ("Pulse:")

    pulse_box.insert('end', str(c_for))
    pulse_box.grid(row=8, column=8)
    pulse_box.place(x=300, y=450)

    PULSE_box = Text(final, font=('arial', 15, 'bold'), fg='red', width=15, height=2, borderwidth=5)
    PULSE_box.pack()
    PULSE_box.insert('end', str(''))
    d_for = ("")

    PULSE_box.insert('end', str(d_for))
    PULSE_box.grid(row=8, column=8)
    PULSE_box.place(x=600, y=450)

    heart_box = Text(final, font=('arial', 15, 'bold'), width=15, height=2, borderwidth=5)
    heart_box.pack()
    e_for = ("Heart Rate:")

    heart_box.insert('end', str(e_for))
    heart_box.grid(row=8, column=8)
    heart_box.place(x=300, y=600)

    HEART_box = Text(final, font=('arial', 15, 'bold'), fg='red', width=15, height=2, borderwidth=5)
    HEART_box.pack()
    HEART_box.insert('end', str(""))
    f_for = ("")

    HEART_box.insert('end', str(f_for))
    HEART_box.grid(row=8, column=8)
    HEART_box.place(x=600, y=600)

    Exit_STAT = Button(final,                               # EXITS THE PROGRAM
                  text="EXIT",
                  command=destroy_op,
                  font=('Arial', 20, "bold"),
                  fg="White",
                  bg="Red",
                  activeforeground='red',
                  activebackground='white',
                  compound=RIGHT)
    Exit_STAT.pack()










def destroy_op():           # EXITS THE PROGRAM
    exit()


def page_3():           # DISPLAYS PAGE 3 OF THE VENTILATOR UPON CLICKING AGREE


    third_window = Tk()
    third_window.title("Age and Weight Selection")
    Select_Label = Label(third_window,                                          #INSERTS BOX FOR REQUEST
                         text="Please Select Who Is Using The Ventilator",
                         font=('Arial', 10, 'bold'),
                         fg='red',
                         relief=RAISED,
                         bd=12,
                         padx=20,
                         pady=20,
                         compound='bottom')
    cont_2 = Button(third_window,                       # CONTINUE BUTTON
                      text="Continue",
                      command=page_final,
                      font=('Arial', 20, "bold"),
                      fg="White",
                      bg="Green",
                      activeforeground='green',
                      activebackground='white',
                      )
    cont_2.pack()                                       # PLACES OBJECT IN WINDOW

    a = IntVar()                                    # HOLDS INDEX AS INTEGER VARIABLE

    k = IntVar()

    statv = ""                                      # ESTABLISHES VARIABLE TO FILL LATER


    for weight in range(len(weights)):                  # USES EARLIER LIST AND INDEXES INTO RADIO BUTTONS
        w_radiobutton = Radiobutton(third_window,
                                    text=weights[weight],
                                    value=weight,
                                    variable=a)
        w_radiobutton.pack()

    for age in range(len(ages)):
        a_radiobutton = Radiobutton(third_window,
                                    text=ages[age],
                                    value=age,
                                    variable=k,
                                    padx=10,
                                    pady=10)
        a_radiobutton.pack()

    if k.get()==0:                                              # ASSIGNS INDEX VALUES TO CHILD OR ADULT
        statv = statv + "Child is using the ventilator"
    elif k.get()==1:
        statv = statv + "Child is using the ventilator"
    elif k.get()==2:
        statv = statv + "Child is using the ventilator"
    elif k.get()==3:
        statv = statv + "Adult is using the ventilator"
    elif k.get()==4:
        statv = statv + "Adult is using the ventilator"
    elif k.get() ==5:
        statv = statv + "Adult is using the ventilator"

    if a.get()==0:
        statv = statv + "      Child weight detected"
    elif a.get()==1:
        statv = statv + "Child weight detected"
    elif a.get()==2:
        statv = statv + "Child weight detected"
    elif a.get() > 3:
        statv = statv + "     Adult is using the ventilator"


    please_enter = Text(third_window, height=5, width=70, )         # ENTERS THE STATV FIELD INTO TEXTBOX FOR DISPLAY
    please_enter.pack()
    please_enter.insert('end', statv)
    please_enter.config(state='disabled')







    enter = '''Please select from the menu, the relevant characteristics'''         # PROMPTS USER TO ENTER INPUTS
    please_enter = Text(third_window, height=5, width=70, )
    please_enter.pack()
    please_enter.insert('end', enter)
    please_enter.config(state='disabled')



    user_display = Text(third_window,height=12,width=70,)
    user_display.insert('end',status_check)
    user_display.pack(expand=True)

    Select_Label.pack()




def page_2():
    consent_form = Tk()                                     # ESTABLISHES WINDOW CREATION (TERMS AND CONDITIONS)
    consent_form.title("Terms and Conditions")              # CHANGES WINDOW TITLE
    consent_form.geometry("1000x1000")                      # SETS WINDOW GEOMETRY

    terms_frame = LabelFrame(consent_form, text="Legal Agreement")
    terms_frame.pack(pady=25)

    terms_txt = Label(terms_frame,
                      text="Creators of this project take no responsibility for any use or adaptations of the material presented."
                           "By proceeding the user accepts all responsibility for their own actions entirely",
                      font=("Ariel", 12, 'bold', 'underline'))
    terms_txt.pack(pady=12, padx=12)

    Continue = Button(consent_form,                     # CONTIUES TO NEXT WINDOW
                      text="Agree",
                      command=page_3,
                      font=('Arial', 20, "bold"),
                      fg="White",
                      bg="Green",
                      activeforeground='green',
                      activebackground='white',
                      compound=CENTER)
    Exit = Button(consent_form,                         # CLOSES THE PROGRAM
                  text="Decline",
                  command=destroy_op,
                  font=('Arial', 20, "bold"),
                  fg="White",
                  bg="Red",
                  activeforeground='red',
                  activebackground='white',
                  compound=CENTER)
    Continue.pack()
    Exit.pack()

    start_screen.destroy()


# Start Screen Code Below

start_screen = Tk()                         # ESTABLISHES START SCREEN WINDOW
start_screen.geometry("1000x1000")          # CHANGES WINDOW DIMENSIONS

start_button = Button(start_screen,             # START BUTTON PARAMETERS
                      text="Start",
                      command=page_2,
                      font=('Arial', 20, "bold"),
                      fg="White",
                      bg="Green",
                      activeforeground='green',
                      activebackground='white')  # Displays Green Start Button at the bottom

start_button.pack(side=BOTTOM)              # PLACES START BUTTON

start_screen.title("Ventilator Project")
Ventimg = PhotoImage(file='img.png')

start_label1 = Label(start_screen,
                     text="Welcome to the Ventilator Project",
                     font=('Arial', 38, 'bold'),
                     fg='black',
                     relief=RAISED,
                     bd=12,
                     padx=20,
                     pady=20,
                     image=Ventimg,
                     compound='bottom'

                     )  # Displays Title and Image of Ventilator
start_label1.pack()

start_screen.mainloop()                         # LOOP FOR WINDOW
